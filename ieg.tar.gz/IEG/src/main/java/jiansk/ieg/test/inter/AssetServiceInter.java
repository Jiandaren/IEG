package jiansk.ieg.test.inter;

import java.io.Serializable;

/**
 * Created by jiansk on 17-7-6.
 */
public interface AssetServiceInter extends Serializable {
}
