package jiansk.ieg.test.inter;

/**
 * for testing
 * Created by jiansk on 17-7-6.
 */
public interface CustServiceInter {
}
