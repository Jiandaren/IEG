package jiansk.ieg.test.inter;

/**
 * Created by jiansk on 17-7-6.
 */
public interface UserServiceInter {
}
